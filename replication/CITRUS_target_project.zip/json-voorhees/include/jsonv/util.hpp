/** \file jsonv/util.hpp
 *  Deprecated. Use \c algorithm.hpp.
 *  
 *  Copyright (c) 2015-2018 by Travis Gockel. All rights reserved.
 *
 *  This program is free software: you can redistribute it and/or modify it under the terms of the Apache License
 *  as published by the Apache Software Foundation, either version 2 of the License, or (at your option) any later
 *  version.
 *
 *  \author Travis Gockel (travis@gockelhut.com)
**/
#include "algorithm.hpp"
