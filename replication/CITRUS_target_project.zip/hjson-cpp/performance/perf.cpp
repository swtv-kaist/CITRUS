void perf_multithread();


int main() {
  perf_multithread();

  return 0;
}
