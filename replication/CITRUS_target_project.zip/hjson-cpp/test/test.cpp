void test_value();
void test_marshal();


int main() {
  test_value();
  test_marshal();

  return 0;
}
