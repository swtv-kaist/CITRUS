#!/bin/bash
set -euo pipefail

cd ./build/src/CMakeFiles/hjson.dir
lcov -c -d . -o lcov.info --rc lcov_branch_coverage=1
genhtml -o html lcov.info --branch-coverage