The docs are html.
To view the docs, please uncompress jvardocs.tar.gz into a folder and open index.html in a browser.
